import SwiftUI

struct WatermelonView: View {
    var body: some View {
        Circle()
            .fill(RadialGradient(gradient: Gradient(colors: [.red, .green]), center: .center, startRadius: 10, endRadius: 80))
            .overlay(Circle().stroke(Color.green, lineWidth: 5))
    }
}
