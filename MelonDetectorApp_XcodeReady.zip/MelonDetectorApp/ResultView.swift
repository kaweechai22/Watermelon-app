import SwiftUI

struct ResultView: View {
    var result: DetectionResult?

    var body: some View {
        if let result = result {
            VStack {
                Text("ความถี่เฉลี่ย: \(result.freq, specifier: "%.2f") Hz")
                Text("ระดับ: \(result.level)")
                Text("%Brix (โดยประมาณ): \(result.brix, specifier: "%.1f") °Bx")
            }
            .padding()
            .background(Color.yellow.opacity(0.2))
            .cornerRadius(10)
        } else {
            EmptyView()
        }
    }
}
