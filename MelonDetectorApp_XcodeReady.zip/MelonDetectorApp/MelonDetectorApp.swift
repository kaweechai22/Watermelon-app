import SwiftUI

@main
struct MelonDetectorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
