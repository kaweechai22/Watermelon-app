import SwiftUI

struct SpectrumView: View {
    var data: [Float]

    var body: some View {
        GeometryReader { geo in
            Path { path in
                guard data.count > 1 else { return }
                let width = geo.size.width
                let height = geo.size.height
                let step = width / CGFloat(data.count - 1)

                path.move(to: .zero)
                for i in 0..<data.count {
                    let x = CGFloat(i) * step
                    let y = height - CGFloat(data[i]) * height
                    path.addLine(to: CGPoint(x: x, y: y))
                }
                path.addLine(to: CGPoint(x: width, y: height))
                path.closeSubpath()
            }
            .fill(Color.green)
        }
    }
}
