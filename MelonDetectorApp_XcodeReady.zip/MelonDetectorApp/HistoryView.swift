import SwiftUI

struct HistoryView: View {
    var history: [DetectionResult]

    var body: some View {
        VStack(alignment: .leading) {
            Text("ประวัติการตรวจวัด").font(.headline)
            ForEach(history.prefix(5)) { item in
                Text("\(item.freq, specifier: "%.2f") Hz - \(item.level) (\(item.brix, specifier: "%.1f") °Bx)")
                    .font(.caption)
            }
        }
    }
}
