import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("แตะปุ่มแล้วเคาะแตงโม 🎤🍉")
                    .font(.title)
                    .padding()

                WatermelonView()
                    .frame(width: 160, height: 160)
                    .padding()

                Button("เริ่มฟังเสียง") {
                    AudioAnalyzer.shared.start()
                }
                .buttonStyle(.borderedProminent)
                .padding()

                Button("เริ่มใหม่") {
                    AudioAnalyzer.shared.reset()
                }
                .buttonStyle(.bordered)

                Text("สถานะ: \(AudioAnalyzer.shared.status)")
                    .padding()

                SpectrumView(data: AudioAnalyzer.shared.spectrumData)
                    .frame(height: 100)
                    .padding()

                ResultView(result: AudioAnalyzer.shared.result)
                    .padding()

                HistoryView(history: AudioAnalyzer.shared.history)
                    .padding()
            }
            .navigationTitle("วัดระดับการสุกของแตงโม")
        }
    }
}
