
import Accelerate

class AudioAnalyzer: NSObject, ObservableObject, AVAudioRecorderDelegate {
    static let shared = AudioAnalyzer()

    @Published var status: String = "รอฟังเสียงเคาะ..."
    @Published var spectrumData: [Float] = []
    @Published var result: DetectionResult? = nil
    @Published var history: [DetectionResult] = []

    private var engine = AVAudioEngine()
    private var tapInstalled = false
    private var tapCount = 0
    private let NUM_TAPS = 3
    private var detectedFrequencies: [Float] = []

    override init() {
        super.init()
    }

    func start() {
        let inputNode = engine.inputNode
        let format = inputNode.inputFormat(forBus: 0)

        if !tapInstalled {
            inputNode.installTap(onBus: 0, bufferSize: 2048, format: format) { buffer, _ in
                self.analyzeBuffer(buffer: buffer, sampleRate: Float(format.sampleRate))
            }
            tapInstalled = true
        }

        do {
            try engine.start()
            status = "กำลังฟัง... กรุณาเคาะแตงโม (\(tapCount+1)/\(NUM_TAPS))"
        } catch {
            status = "ไม่สามารถเริ่มต้นเครื่องเสียง"
        }
    }

    func reset() {
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
        tapInstalled = false
        tapCount = 0
        detectedFrequencies = []
        status = "สถานะ: รอฟังเสียงเคาะ..."
        result = nil
    }

    private func analyzeBuffer(buffer: AVAudioPCMBuffer, sampleRate: Float) {
        guard let channelData = buffer.floatChannelData?[0] else { return }
        let frameLength = Int(buffer.frameLength)

        var window = [Float](repeating: 0, count: frameLength)
        vDSP_hann_window(&window, vDSP_Length(frameLength), Int32(vDSP_HANN_NORM))

        var windowedSamples = [Float](repeating: 0, count: frameLength)
        vDSP_vmul(channelData, 1, window, 1, &windowedSamples, 1, vDSP_Length(frameLength))

        var realp = [Float](repeating: 0.0, count: frameLength/2)
        var imagp = [Float](repeating: 0.0, count: frameLength/2)
        var output = DSPSplitComplex(realp: &realp, imagp: &imagp)

        let fftSetup = vDSP_create_fftsetup(vDSP_Length(log2(Float(frameLength))), FFTRadix(FFT_RADIX2))!
        windowedSamples.withUnsafeBufferPointer { ptr in
            ptr.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: frameLength) { typeConvertedTransferBuffer in
                vDSP_ctoz(typeConvertedTransferBuffer, 2, &output, 1, vDSP_Length(frameLength / 2))
            }
        }

        vDSP_fft_zrip(fftSetup, &output, 1, vDSP_Length(log2(Float(frameLength))), FFTDirection(FFT_FORWARD))
        var magnitudes = [Float](repeating: 0.0, count: frameLength/2)
        vDSP_zvmags(&output, 1, &magnitudes, 1, vDSP_Length(frameLength / 2))

        var maxMag: Float = 0
        var maxIndex: vDSP_Length = 0
        vDSP_maxvi(magnitudes, 1, &maxMag, &maxIndex, vDSP_Length(magnitudes.count))

        let frequency = Float(maxIndex) * sampleRate / Float(frameLength)
        if frequency >= 100 && frequency <= 1200 {
            DispatchQueue.main.async {
                self.engine.inputNode.removeTap(onBus: 0)
                self.engine.stop()
                self.tapInstalled = false
                self.detectedFrequencies.append(frequency)
                self.tapCount += 1

                if self.tapCount < self.NUM_TAPS {
                    self.status = "ตรวจพบความถี่รอบที่ \(self.tapCount): \(String(format: "%.2f", frequency)) Hz\nกำลังรอฟังรอบถัดไป (\(self.tapCount+1)/\(self.NUM_TAPS))..."
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        self.start()
                    }
                } else {
                    let avgFreq = self.detectedFrequencies.reduce(0, +) / Float(self.NUM_TAPS)
                    self.status = "ตรวจครบ \(self.NUM_TAPS) ครั้ง ความถี่เฉลี่ย: \(String(format: "%.2f", avgFreq)) Hz"
                    self.evaluate(freq: avgFreq)
                    self.tapCount = 0
                    self.detectedFrequencies = []
                }
            }
        }

        vDSP_destroy_fftsetup(fftSetup)
    }

    private func evaluate(freq: Float) {
        var level = ""
        var sweetness = ""
        var brix = 4.9917e-8 * pow(Double(freq), 3) - 1.6903e-4 * pow(Double(freq), 2) + 0.12663 * Double(freq) - 15.5724
        brix = max(3, min(brix, 20))

        if freq > 700 {
            level = "ดิบ"
            sweetness = "น้อยมาก"
        } else if freq > 600 {
            level = "ใกล้สุก"
            sweetness = "น้อย"
        } else if freq >= 350 {
            level = "สุกพอดี"
            sweetness = "หวาน"
        } else {
            level = "อาจเน่า"
            sweetness = "เปรี้ยว / เสีย"
        }

        let result = DetectionResult(freq: freq, brix: brix, level: level)
        self.result = result
        self.history.insert(result, at: 0)

        let msg = AVSpeechUtterance(string: "แตงโมระดับ \(level), ความหวาน \(sweetness), ประมาณ \(String(format: "%.1f", brix)) บริกซ์")
        msg.voice = AVSpeechSynthesisVoice(language: "th-TH")
        AVSpeechSynthesizer().speak(msg)
    }
}
